import random
import sys


class FLClient:
    def __init__(self, client_id: int):
        self.client_id = client_id

    def generate_feature_vector(self):
        # 18 features like the VeReMi-based MLP expects
        return [round(random.uniform(-1, 1), 4) for _ in range(18)]


if __name__ == "__main__":
    client_id = int(sys.argv[1]) if len(sys.argv) > 1 else 0

    client = FLClient(client_id)
    features = client.generate_feature_vector()

    # print as comma-separated values
    print(",".join(map(str, features)))