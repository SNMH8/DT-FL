import subprocess
from src.digital_twin.digital_twin_engine import DigitalTwinEngine


class FLServer:
    def __init__(self, num_clients=5):
        print("FL Server Initialized")
        self.num_clients = num_clients
        self.dt = DigitalTwinEngine()

    def _get_client_features(self, client_id: int):
        cmd = ["python", "-m", "src.fl.fl_client", str(client_id)]
        result = subprocess.run(cmd, capture_output=True, text=True)

        if result.returncode != 0:
            raise RuntimeError(
                f"Client {client_id} failed.\nSTDERR:\n{result.stderr}"
            )

        line = result.stdout.strip()
        features = [float(x) for x in line.split(",")]
        return features

    def run_round(self, round_id: int = 1):
        print(f"\n===== ROUND {round_id} =====")
        print("Starting FL Round...")

        valid_updates = []

        for i in range(self.num_clients):
            features = self._get_client_features(i)

            malicious, prob = self.dt.detect_malicious_update(features)

            print(f"Client {i} DT probability: {prob:.4f}")

            if malicious:
                print(f"[WARNING] Client {i} flagged as malicious. Update discarded.")
            else:
                # temporary scalar update from accepted feature vector
                update = round(sum(features) / len(features), 4)
                print(f"Client {i} accepted update: {update}")
                valid_updates.append(update)

        if len(valid_updates) > 0:
            global_model = round(sum(valid_updates) / len(valid_updates), 4)
            print(f"\nNew Global Model Value: {global_model}")
        else:
            print("\nNo valid client updates received.")

        print("System Running Successfully!")


if __name__ == "__main__":
    server = FLServer(num_clients=5)

    for r in range(1, 4):
        server.run_round(round_id=r)