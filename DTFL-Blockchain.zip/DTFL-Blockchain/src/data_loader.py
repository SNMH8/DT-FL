import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split


def load_sample_data(path, nrows=100000):
    print("Loading sample from dataset...")

    df = pd.read_csv(path, nrows=nrows)

    # Remove useless column
    if "Unnamed: 0" in df.columns:
        df = df.drop(columns=["Unnamed: 0"])

    print("Data Loaded Successfully!")
    print("Shape:", df.shape)

    return df


def preprocess_data(
    df,
    target_col="attack",
    multiclass_col="attack_type",
    test_size=0.2,
    random_state=42
):
    print("\nStarting Preprocessing...")

    # Features
    X = df.drop(columns=[target_col, multiclass_col])

    # Target (Binary)
    y = df[target_col]

    # 1) Split first
    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=test_size,
        random_state=random_state,
        stratify=y
    )

    # 2) Fit scaler only on training data
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    print("Preprocessing Done!")
    print("Train shape:", X_train_scaled.shape)
    print("Test shape:", X_test_scaled.shape)

    return X_train_scaled, X_test_scaled, y_train, y_test, scaler


if __name__ == "__main__":
    df = load_sample_data("data/veremi.csv", nrows=100000)

    print("\nAttack Distribution:")
    print(df["attack"].value_counts())

    print("\nAttack Type Distribution:")
    print(df["attack_type"].value_counts())

    # Preprocessing
    X_train, X_test, y_train, y_test, scaler = preprocess_data(df)