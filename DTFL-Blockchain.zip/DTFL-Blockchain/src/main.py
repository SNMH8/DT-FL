from src.fl.fl_server import FLServer
from src.security.misbehavior_detector import MisbehaviorDetector
from src.blockchain.reputation_manager import ReputationManager
from src.digital_twin.digital_twin_engine import DigitalTwinEngine

def main():
    print("DT-FL Blockchain System Starting...\n")

    fl_server = FLServer()

    for i in range(3):
        print(f"\n========== FL Round {i+1} ==========")
        fl_server.run_round()

    print("\nSystem Running Successfully!")


if __name__ == "__main__":
    main()