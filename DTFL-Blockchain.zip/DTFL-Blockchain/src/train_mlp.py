# Baseline MLP for VeReMi Misbehavior Detection

import random
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report

from data_loader import load_sample_data, preprocess_data


# ---------------------------
# 1) Reproducibility
# ---------------------------
def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


set_seed(42)


# ---------------------------
# 2) Define Model
# ---------------------------
class MLP(nn.Module):
    def __init__(self, input_dim):
        super(MLP, self).__init__()

        self.model = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.ReLU(),
            nn.Dropout(0.3),

            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Dropout(0.3),

            nn.Linear(64, 1)   # no Sigmoid here
        )

    def forward(self, x):
        return self.model(x)


# ---------------------------
# 3) Load and preprocess data
# ---------------------------
df = load_sample_data("data/veremi.csv", nrows=100000)

# returns scaled train/test + scaler
X_train_full, X_test, y_train_full, y_test, scaler = preprocess_data(df)

# Create validation set from training data only
X_train, X_val, y_train, y_val = train_test_split(
    X_train_full,
    y_train_full,
    test_size=0.2,
    random_state=42,
    stratify=y_train_full
)

print("\nValidation split created!")
print("Train shape:", X_train.shape)
print("Validation shape:", X_val.shape)
print("Test shape:", X_test.shape)


# ---------------------------
# 4) Convert to tensors
# ---------------------------
X_train_tensor = torch.FloatTensor(X_train)
X_val_tensor = torch.FloatTensor(X_val)
X_test_tensor = torch.FloatTensor(X_test)

y_train_tensor = torch.FloatTensor(y_train.values).unsqueeze(1)
y_val_tensor = torch.FloatTensor(y_val.values).unsqueeze(1)
y_test_tensor = torch.FloatTensor(y_test.values).unsqueeze(1)

train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
val_dataset = TensorDataset(X_val_tensor, y_val_tensor)

train_loader = DataLoader(train_dataset, batch_size=256, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=256, shuffle=False)


# ---------------------------
# 5) Initialize model
# ---------------------------
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("\nUsing device:", device)

model = MLP(input_dim=X_train.shape[1]).to(device)

# Class weighting for imbalanced attack detection
n_neg = (y_train == 0).sum()
n_pos = (y_train == 1).sum()
pos_weight = torch.tensor([n_neg / n_pos], dtype=torch.float32).to(device)

criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight)
optimizer = optim.Adam(model.parameters(), lr=0.001)


# ---------------------------
# 6) Training loop + validation + early stopping
# ---------------------------
epochs = 50
patience = 7
best_val_loss = float("inf")
patience_counter = 0
best_model_path = "best_mlp_model.pth"

for epoch in range(epochs):
    # ---- Training ----
    model.train()
    total_train_loss = 0.0

    for X_batch, y_batch in train_loader:
        X_batch = X_batch.to(device)
        y_batch = y_batch.to(device)

        optimizer.zero_grad()
        logits = model(X_batch)
        loss = criterion(logits, y_batch)
        loss.backward()
        optimizer.step()

        total_train_loss += loss.item()

    avg_train_loss = total_train_loss / len(train_loader)

    # ---- Validation ----
    model.eval()
    total_val_loss = 0.0

    with torch.no_grad():
        for X_batch, y_batch in val_loader:
            X_batch = X_batch.to(device)
            y_batch = y_batch.to(device)

            logits = model(X_batch)
            val_loss = criterion(logits, y_batch)
            total_val_loss += val_loss.item()

    avg_val_loss = total_val_loss / len(val_loader)

    print(
        f"Epoch {epoch+1}/{epochs}, "
        f"Train Loss: {avg_train_loss:.4f}, "
        f"Val Loss: {avg_val_loss:.4f}"
    )

    # ---- Save best model ----
    if avg_val_loss < best_val_loss:
        best_val_loss = avg_val_loss
        patience_counter = 0
        torch.save(model.state_dict(), best_model_path)
        print("Best model saved.")
    else:
        patience_counter += 1

    # ---- Early stopping ----
    if patience_counter >= patience:
        print("Early stopping triggered.")
        break


# ---------------------------
# 7) Load best model
# ---------------------------
model.load_state_dict(torch.load(best_model_path, map_location=device))
model.eval()


# ---------------------------
# 8) Final test evaluation
# ---------------------------
with torch.no_grad():
    X_test_tensor = X_test_tensor.to(device)
    logits = model(X_test_tensor)
    probs = torch.sigmoid(logits)
    preds = (probs > 0.5).float().cpu().numpy()

y_true = y_test_tensor.cpu().numpy()

accuracy = accuracy_score(y_true, preds)
print("\nTest Accuracy:", accuracy)
print("\nClassification Report:")
print(classification_report(y_true, preds, digits=4))

print("\nTraining Finished!")
print("Best model saved as:", best_model_path)