import torch
import torch.nn as nn
import numpy as np


class MLP(nn.Module):

    def __init__(self, input_dim):
        super(MLP, self).__init__()

        self.model = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.ReLU(),
            nn.Dropout(0.3),

            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Dropout(0.3),

            nn.Linear(64, 1)
        )

    def forward(self, x):
        return self.model(x)

    def forward(self, x):
        return self.model(x)


class DigitalTwinEngine:

    def __init__(self, model_path="best_mlp_model.pth", input_dim=18):

        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        self.model = MLP(input_dim)
        self.model.load_state_dict(torch.load(model_path, map_location=self.device))

        self.model.to(self.device)
        self.model.eval()

        print("Digital Twin Engine Initialized")

    def detect_malicious_update(self, feature_vector):

        x = np.array(feature_vector).reshape(1, -1)
        x = torch.FloatTensor(x).to(self.device)

        with torch.no_grad():

            logits = self.model(x)
            prob = torch.sigmoid(logits).item()

            if prob > 0.5:
                return True, prob
            else:
                return False, prob


if __name__ == "__main__":

    sample = [0.1]*18

    dt = DigitalTwinEngine()

    malicious, prob = dt.detect_malicious_update(sample)

    if malicious:
        print("Malicious client detected", prob)
    else:
        print("Benign client", prob)