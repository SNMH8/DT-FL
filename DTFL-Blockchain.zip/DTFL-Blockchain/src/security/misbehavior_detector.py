class MisbehaviorDetector:
    def __init__(self):
        print("MisbehaviorDetector Initialized")

    def is_malicious(self, update):
        if update < -0.8:
            return True
        return False