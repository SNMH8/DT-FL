class ReputationManager:
    def __init__(self):
        print("ReputationManager initialized")